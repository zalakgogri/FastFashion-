which generation produces the most carbon footprint on earth? 
hence does the carbon footprint reduce as one grows?
Gender wise current carbon footprint
* Gender wise and temporal wise footprint delta (to - do)
Averagely which generation produces what amount of carbon footprint


GRAPHS :
    BAR-GRAPHS
        cloths - wise carbon produced per generation (5 graphs)
        carbon produced per cloth (1)
        generation-wise carbon footprint and number of cloth bought(1)
        number of gender , generation (2)
        number of cloths bought gender wise and carbon footprint (1)
    PIE-CHART
        gender wise carbon footprint (1)
    LINE-CHART
        temporal change in carbon footprint (1)
        change in cloth buying trend (1)


